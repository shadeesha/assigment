package com.uk.tn.ex.entity;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;

import javax.persistence.PrePersist;
import java.sql.Timestamp;

public class AuditListener {

    @PrePersist
    public void setCreatedOn(Auditable auditable) {
        Audit audit = auditable.getAudit();

        if (audit == null) {
            audit = new Audit();
            auditable.setAudit(audit);
        }

        SecurityContext context = SecurityContextHolder.getContext();
        String user = (context != null && context.getAuthentication() != null
                ? ((User) context.getAuthentication().getPrincipal()).getUsername()
                : "SYSTEM");
        if (user != null) {
            audit.setCreatedBy(user);
        } else {
            audit.setCreatedBy("SYSTEM");
        }
        audit.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
    }
}
