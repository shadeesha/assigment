package com.uk.tn.ex.entity.dv;

import com.uk.tn.ex.entity.AuditListener;
import com.uk.tn.ex.entity.Auditable;
import com.uk.tn.ex.entity.dto.DeviceDTO;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;


@Getter
@Setter
@Table
@Entity
@EntityListeners(AuditListener.class)
public class Device extends Auditable<DeviceDTO> {

    @Column
    private String RecordType;

    @Column
    private long DeviceId;

    @Column
    private Date EventDateTime;

    @Column
    private int FieldA;

    @Column
    private String FieldB;

    @Column
    private double FieldC;
}
