package com.uk.tn.ex.service;

import com.uk.tn.ex.entity.dv.Device;
import com.uk.tn.ex.repository.DeviceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class DeviceService {

    @Autowired
    DeviceRepository deviceRepository;

    @Transactional
    public void save(Device device) throws Exception {
        try{
            deviceRepository.save(device);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
