package com.uk.tn.ex.controller;

import com.uk.tn.ex.entity.dv.Device;
import com.uk.tn.ex.service.DeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeviceController {

    @Autowired
    DeviceService deviceService;

    @RequestMapping(method = RequestMethod.POST, value = "/save")
    public ResponseEntity saveDevice(@RequestBody Device device) throws Exception {
        try{

            deviceService.save(device);
        }catch (Exception e){
            return ResponseEntity.ok("");
        }
        return ResponseEntity.created(null).build();
    }



    @RequestMapping(method = RequestMethod.POST, value = "/nocontent")
    public ResponseEntity noContent(@RequestBody Device device) throws Exception {
        return ResponseEntity.noContent().build();
    }

    @RequestMapping(method = RequestMethod.POST, value = "/echo")
    public ResponseEntity echoConent(@RequestBody Device device) throws Exception {
        return ResponseEntity.ok().body(device);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/device")
    public ResponseEntity findDevice(@RequestBody Device device) throws Exception {
        return ResponseEntity.ok().body(device.getDeviceId());
    }

    @RequestMapping(method = RequestMethod.POST, value = "/*")
    public ResponseEntity notFound(@RequestBody Device device) throws Exception {
        return ResponseEntity.badRequest().build();
    }






}
