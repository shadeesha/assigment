package com.uk.tn.ex.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Embeddable
public class Audit implements Serializable {

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "created_timestamp")
    private Date createdTimestamp;

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setCreatedTimestamp(Date createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

}
