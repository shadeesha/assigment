package com.uk.tn.ex.entity.dto;

import com.uk.tn.ex.entity.Auditable;
import lombok.Getter;
import lombok.Setter;
import org.modelmapper.ModelMapper;

import java.io.Serializable;

@Setter
@Getter
public abstract class  BaseDTO <T extends Auditable>implements Serializable {

    private Long id;

    public T toEntity(Class<T> type){
        ModelMapper mapper=new ModelMapper();
        T entity=mapper.map(this,type);
        entity.setId(this.id);
        return entity;
    }
}
