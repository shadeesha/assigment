package com.uk.tn.ex.entity.dto;

import com.uk.tn.ex.entity.dv.Device;
import java.util.Date;

public class DeviceDTO extends BaseDTO<Device> {

    private String RecordType;
    private long DeviceId;
    private Date EventDateTime;
    private int FieldA;
    private String FieldB;
    private double FieldC;
}
