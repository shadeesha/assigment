package com.uk.tn.ex.controller;

import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.skyscreamer.jsonassert.JSONAssert;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class DeviceControllerTest {

    @Autowired
    private MockMvc mockMvc;


    @Test
    void saveDevice() throws Exception {
        JSONObject bodyObject = new JSONObject();
        bodyObject.put("recordType", "yyy");
        bodyObject.put("deviceId", "123456789012345");
        bodyObject.put("eventDateTime", "2022-05-12T05:09:48Z");
        bodyObject.put("fieldA", "100");
        bodyObject.put("fieldB", "yyy");
        bodyObject.put("fieldC", "200.45");

        MvcResult mvcResult = mockMvc.perform(post("/save", 42L)
                .contentType("application/json")
                .header("authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmb28iLCJleHAiOjE2NDg5Njk5OTAsImlhdCI6MTY0ODkzMzk5MH0.ql4uhXmShezbS4faQb6_koO8sd7JsRVKkx9fo5RUKQY")
                .content(bodyObject.toString()))
                .andExpect(status().isCreated()).andReturn();


        ResponseEntity expected = ResponseEntity.created(null).build();
        JSONAssert.assertEquals(Integer.toString(expected.getStatusCodeValue()), Integer.toString(mvcResult.getResponse().getStatus()), false);
    }

}